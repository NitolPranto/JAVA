public class MAIN{
	public static void main(String a[]){
		Hhome f=new Hhome();
		f.setVisible(true);
		//Navigate n=new Navigate();
		//n.setVisible(true);
	}
}