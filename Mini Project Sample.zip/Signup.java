import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Signup extends Frame implements ActionListener{
	private TextField name,email;
	private Button signupButton,cancelButton;
	private Label l,l2,msg;
	public Signup(){
		super("Java Signup Window");
		l=new Label("Name: ");
		name=new TextField(10);
		l2=new Label("Email: ");
		email=new TextField(10);
		signupButton=new Button("Signup");
		cancelButton=new Button("Cancel");
		msg=new Label("msg box");
		add(l);add(name);
		add(l2);add(email);
		add(signupButton);add(cancelButton);
		add(msg);
		
		l.setBounds(10,60,50,30);
		name.setBounds(115,60,200,30);
		l2.setBounds(10,95,100,30);
		email.setBounds(115,95,200,30);
		signupButton.setBounds(115,130,100,30);
		cancelButton.setBounds(220,130,100,30);
		msg.setBounds(215,170,200,30);
		
		signupButton.addActionListener(this);
		cancelButton.addActionListener(this);
		setLayout(null);
		setSize(400,500);
	}
	private boolean isEmpty(TextField s){
		boolean flag=false;
		if(s.getText().length()==0)flag=true;
		//System.out.println(s.getText()+":"+flag);
		return flag;
	}
	private boolean isValidEmail(String e){
		boolean flag=true;
		int atIdx=e.indexOf("@");
		int dotIdx=e.indexOf(".");
		if(dotIdx<=atIdx)flag=false;
		return flag;
	}
	public void actionPerformed(ActionEvent e){
		//System.out.println(e.getActionCommand());
		String sig=e.getActionCommand();
		
		if(sig.equals("Signup")){
			if(isEmpty(name) || isEmpty(email)){
				JOptionPane.showMessageDialog(this,"All fields are mandatory");
			}
			else if(!isValidEmail(email.getText())){
				JOptionPane.showMessageDialog(this,"Invalid Email");
			}
			else{
				DataAccess da=new DataAccess();
				String sql="insert into user values('"+name.getText()+"','111','"+email.getText()+"')";
				if(da.updateDB(sql)>0){
					JOptionPane.showMessageDialog(this,"Signup Complete!");
				}
				System.out.println(sql);
			}
		}
		else if(sig.equals("Cancel")){
			System.exit(0);
		}
	}
}