import java.util.Scanner;
public class AC{
	public static void main(String w[]){
		
		Scanner sc=new Scanner(System.in);
		Scanner sc2=new Scanner(System.in);
		Scanner sc3=new Scanner(System.in);
		Scanner sc4=new Scanner(System.in);
		Scanner sc5=new Scanner(System.in);
		
		String n=sc.nextLine();
		String i=sc2.nextLine();
		int a=sc3.nextInt();
		String m=sc4.nextLine();
		String  c=sc5.nextLine();
		
		Contact c=new Contact();
		c.setpersonName(n);
		c.setpersonId(i);
		c.setage(a);
		c.setmobileNumber(m);
		c.setgender(g);
		
		c.showInfo();
		
		
		
		
	}
}
class Contact{
	private String personName;
	private String personId;
	private int age;
	private String mobileNumber;
	private String gender;
	
	public Contact(){}
	public Contact(String n, String i){
	personName=n;
	personId=i;}
	

	public void setpersonName(String n){personName=n;}
	public void setpersonId(String i){personId=i;}	
	public void setage(int a){age=a;}
	public void setmobileNumber(String m){mobileNumber=m;}
	public void setgender(String g){gender=g;}
	
	public void showInfo(){
		System.out.println("Person Name : "+personName);
		System.out.println("Person ID : "+personId);
		System.out.println("Age : "+age);
		System.out.println("Mobile Number : "+mobileNumber);
		System.out.println("Gender : "+gender);
		
	}
	
	

}